﻿# 馨客栈

关注分享，关注导航，关注馨客栈

## 馨客栈导航

http://mackxin.com/nav.html

## 馨客栈前端导航

http://mackxin.com/webnav.html

## 馨客栈每日分享

http://mackxin.com/fx.html

## 馨客栈微博

http://weibo.com/xininn

## 馨客栈源码

https://github.com/Mackxin/mackxin

## 仿小米官网首页地址

https://mackxin.github.io/mi.com