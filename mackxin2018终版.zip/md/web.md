

## ssr: 将一个目录设置成一个静态服务器的命令行工具。

[github地址](https://github.com/jaywcjlove/ssr)   