# Window必备的软件
---

### everything
> Everything是一个私有的免费Windows桌面搜索引擎，可以在NTFS卷上快速地根据名称查找文件和目录   
[下载地址](http://www.voidtools.com/)   

### Seer
> window下的快速查看工具，操作行为就像在macOS中一样，但是Seer更强大，可定制，更快   
[下载地址](http://www.1218.io/)

### QuickLook
> 也是Windows快速预览工具,相比较上面的seer，你们可以自己体验斟酌哈   
[下载地址](https://pooi.moe/QuickLook/)

### Traffic Monitor   
> 一款用于Windows平台的网速监控悬浮窗软件，可以显示当前网速、CPU及内存利用率，支持嵌入到任务栏显示，支持更换皮肤、历史流量统计等功能
[下载地址](https://github.com/zhongyang219/TrafficMonitor/releases)   

### Aria2 - 超・懒人包   
> 只需要两步骤：
> 1.运行这个自解压文件 2（分流下载）
> 2.等待桌面出现 AriaNg 快捷方式，双击运行它
> 然后你就可以点击 「新建」 开始下载了！默认下载目录是 C 盘桌面。另外就算重启系统，也还是能直接打开 AriaNg 进行下载的。   
[下载地址](https://www.lanzous.com/i26o4yf)   密码:ejx6
